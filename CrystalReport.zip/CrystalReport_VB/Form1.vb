﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Public Class Form1

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim crystalReport As New CustomerReport()
        Dim dsCustomers As Customers = GetData()
        crystalReport.SetDataSource(dsCustomers)
        Me.CrystalReportViewer1.ReportSource = crystalReport
        Me.CrystalReportViewer1.RefreshReport()
    End Sub

    Private Function GetData() As Customers
        Dim constr As String = "Data Source=.\Sql2005;Initial Catalog=Northwind;Integrated Security = true"
        Using con As New SqlConnection(constr)
            Using cmd As New SqlCommand("SELECT TOP 20 * FROM Customers")
                Using sda As New SqlDataAdapter()
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    Using dsCustomers As New Customers()
                        sda.Fill(dsCustomers, "DataTable1")
                        Return dsCustomers
                    End Using
                End Using
            End Using
        End Using
    End Function
End Class
